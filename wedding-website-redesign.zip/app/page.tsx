import { HeroSection } from '@/components/hero-section'
import { WelcomeSection } from '@/components/welcome-section'
import { CoupleSection } from '@/components/couple-section'
import { EventsSection } from '@/components/events-section'
import { GallerySection } from '@/components/gallery-section'
import { VenueSection } from '@/components/venue-section'
import { FooterSection } from '@/components/footer-section'
import { FloatingFloral } from '@/components/floral-decorations'

export default function WeddingInvitation() {
  return (
    <main className="relative min-h-screen overflow-x-hidden">
      {/* Floating floral decorations */}
      <FloatingFloral />
      
      {/* Page sections */}
      <HeroSection />
      <WelcomeSection />
      <CoupleSection />
      <EventsSection />
      <GallerySection />
      <VenueSection />
      <FooterSection />
    </main>
  )
}
