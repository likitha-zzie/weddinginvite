'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import { FloralCorner } from './floral-decorations'

export function FooterSection() {
  return (
    <footer id="footer" className="relative py-16 md:py-24 px-4 overflow-hidden">
      {/* Background Image with blur */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-SGbKamDetPbqlCJmzdS9RqXpAc86Tw.png"
          alt="Background"
          fill
          className="object-cover object-[center_30%] blur-md scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-teal-900/70 via-teal-800/60 to-teal-900/80" />
      </div>
      
      {/* Floral corners */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-40">
        <FloralCorner position="top-left" />
        <FloralCorner position="top-right" />
        <FloralCorner position="bottom-left" />
        <FloralCorner position="bottom-right" />
      </div>

      <div className="max-w-3xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass rounded-3xl p-8 md:p-12 text-center relative overflow-hidden"
          style={{
            background: 'rgba(255, 255, 255, 0.15)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: '1px solid rgba(255, 255, 255, 0.25)',
          }}
        >
          {/* Decorative top border */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />

          {/* Floral decoration top */}
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mb-6"
          >
            <svg className="w-16 h-8 mx-auto text-amber-300/60" viewBox="0 0 80 30" fill="none">
              <path d="M0 25 Q20 5 40 15 Q60 25 80 5" stroke="currentColor" strokeWidth="1" />
              <circle cx="40" cy="15" r="4" fill="currentColor" />
              <circle cx="20" cy="18" r="2" fill="currentColor" opacity="0.6" />
              <circle cx="60" cy="12" r="2" fill="currentColor" opacity="0.6" />
            </svg>
          </motion.div>

          {/* Thank You Heading */}
          <motion.h2
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="font-cursive text-4xl md:text-6xl text-white mb-6"
            style={{ textShadow: '0 2px 10px rgba(0,0,0,0.3)' }}
          >
            Thank You
          </motion.h2>

          {/* Message */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-white/90 text-lg md:text-xl font-serif leading-relaxed mb-8"
          >
            We look forward to celebrating this special day with you.
            <br />
            <span className="text-amber-200/80 text-base mt-2 block">
              Your presence will make our day even more memorable.
            </span>
          </motion.p>

          {/* Decorative divider */}
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 }}
            className="flex items-center justify-center gap-4 mb-8"
          >
            <div className="h-px w-12 md:w-20 bg-amber-300/40" />
            <svg className="w-6 h-6 text-amber-300/70" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
            </svg>
            <div className="h-px w-12 md:w-20 bg-amber-300/40" />
          </motion.div>

          {/* Wedding Date */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6 }}
            className="space-y-2"
          >
            <p className="font-cursive text-2xl md:text-3xl text-white">
              June 21, 2026
            </p>
            <p className="text-white/70 text-sm md:text-base">
              R G Convention Hall, Malur Town
            </p>
          </motion.div>

          {/* Couple Names */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.8 }}
            className="mt-10 pt-8 border-t border-white/20"
          >
            <p className="font-cursive text-3xl md:text-4xl text-amber-200">
              Divya & Pramodh
            </p>
          </motion.div>

          {/* Floral decoration bottom */}
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.9 }}
            className="mt-6"
          >
            <svg className="w-16 h-8 mx-auto text-amber-300/60 rotate-180" viewBox="0 0 80 30" fill="none">
              <path d="M0 25 Q20 5 40 15 Q60 25 80 5" stroke="currentColor" strokeWidth="1" />
              <circle cx="40" cy="15" r="4" fill="currentColor" />
              <circle cx="20" cy="18" r="2" fill="currentColor" opacity="0.6" />
              <circle cx="60" cy="12" r="2" fill="currentColor" opacity="0.6" />
            </svg>
          </motion.div>

          {/* Decorative bottom border */}
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />
        </motion.div>

        {/* Copyright */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 1 }}
          className="text-center text-white/50 text-sm mt-8"
        >
          Made with love for our special day
        </motion.p>
      </div>
    </footer>
  )
}
