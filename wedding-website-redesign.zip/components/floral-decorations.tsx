'use client'

import { motion } from 'framer-motion'

export function FloralCorner({ position }: { position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' }) {
  const positionClasses = {
    'top-left': 'top-0 left-0',
    'top-right': 'top-0 right-0 rotate-90',
    'bottom-left': 'bottom-0 left-0 -rotate-90',
    'bottom-right': 'bottom-0 right-0 rotate-180',
  }

  return (
    <motion.svg
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1, delay: 0.5 }}
      className={`absolute w-24 h-24 md:w-32 md:h-32 lg:w-40 lg:h-40 pointer-events-none ${positionClasses[position]}`}
      viewBox="0 0 150 150"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Main floral branch */}
      <motion.path
        d="M10 10 Q30 30 40 60 Q50 90 30 120"
        stroke="#5f9ea0"
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 2, delay: 0.8 }}
      />
      <motion.path
        d="M40 60 Q60 50 80 70"
        stroke="#5f9ea0"
        strokeWidth="1"
        fill="none"
        strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 1.5, delay: 1 }}
      />
      
      {/* Leaves */}
      <motion.ellipse
        cx="25"
        cy="40"
        rx="8"
        ry="15"
        fill="#b8860b"
        fillOpacity="0.3"
        transform="rotate(-30 25 40)"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 1.2 }}
      />
      <motion.ellipse
        cx="50"
        cy="80"
        rx="6"
        ry="12"
        fill="#5f9ea0"
        fillOpacity="0.25"
        transform="rotate(20 50 80)"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 1.4 }}
      />
      <motion.ellipse
        cx="35"
        cy="100"
        rx="7"
        ry="14"
        fill="#b8860b"
        fillOpacity="0.2"
        transform="rotate(-15 35 100)"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 1.6 }}
      />
      
      {/* Small flowers */}
      <motion.circle
        cx="60"
        cy="55"
        r="4"
        fill="#5f9ea0"
        fillOpacity="0.4"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.3, delay: 1.8 }}
      />
      <motion.circle
        cx="75"
        cy="68"
        r="3"
        fill="#b8860b"
        fillOpacity="0.35"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.3, delay: 2 }}
      />
      
      {/* Decorative dots */}
      <motion.circle cx="20" cy="25" r="2" fill="#5f9ea0" fillOpacity="0.3" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 2.2 }} />
      <motion.circle cx="45" cy="45" r="1.5" fill="#b8860b" fillOpacity="0.25" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 2.3 }} />
      <motion.circle cx="25" cy="115" r="2" fill="#5f9ea0" fillOpacity="0.3" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 2.4 }} />
    </motion.svg>
  )
}

export function FloralDivider() {
  return (
    <motion.div
      initial={{ opacity: 0, scaleX: 0 }}
      whileInView={{ opacity: 1, scaleX: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="flex items-center justify-center gap-4 py-8"
    >
      <div className="h-px w-16 md:w-24 bg-gradient-to-r from-transparent to-primary/50" />
      <svg className="w-8 h-8 text-primary" viewBox="0 0 40 40" fill="none">
        <path
          d="M20 5 C25 10 30 15 25 20 C20 25 10 20 5 15 C0 10 10 5 20 5"
          stroke="currentColor"
          strokeWidth="1.5"
          fill="none"
        />
        <path
          d="M20 35 C15 30 10 25 15 20 C20 15 30 20 35 25 C40 30 30 35 20 35"
          stroke="currentColor"
          strokeWidth="1.5"
          fill="none"
        />
        <circle cx="20" cy="20" r="2" fill="currentColor" opacity="0.5" />
      </svg>
      <div className="h-px w-16 md:w-24 bg-gradient-to-l from-transparent to-primary/50" />
    </motion.div>
  )
}

export function FloatingFloral() {
  const florals = [
    { x: '10%', y: '20%', size: 20, delay: 0 },
    { x: '85%', y: '30%', size: 16, delay: 0.5 },
    { x: '15%', y: '60%', size: 18, delay: 1 },
    { x: '90%', y: '70%', size: 14, delay: 1.5 },
    { x: '5%', y: '85%', size: 22, delay: 2 },
  ]

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {florals.map((floral, index) => (
        <motion.div
          key={index}
          className="absolute opacity-20"
          style={{ left: floral.x, top: floral.y }}
          initial={{ opacity: 0, y: 20 }}
          animate={{
            opacity: [0.1, 0.25, 0.1],
            y: [0, -10, 0],
          }}
          transition={{
            duration: 4,
            delay: floral.delay,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
        >
          <svg width={floral.size} height={floral.size} viewBox="0 0 24 24" fill="none">
            <path
              d="M12 2 C14 6 18 8 18 12 C18 16 14 18 12 22 C10 18 6 16 6 12 C6 8 10 6 12 2"
              fill="#5f9ea0"
              opacity="0.6"
            />
          </svg>
        </motion.div>
      ))}
    </div>
  )
}
