'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'

const couple = {
  bride: {
    name: 'Divya T N',
    role: 'The Bride',
    description: 'Bringing elegance, joy, and a little bit of magic wherever she goes.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-YJ8DKcjF8ZWgxT9fVVvu69EJ7Npcdn.png',
  },
  groom: {
    name: 'Pramodh K N',
    role: 'The Groom',
    description: 'Making every journey brighter with love and laughter.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-XyraFn4Vsk7U2WYNhaNK7i3h6kpMSX.png',
  },
}

function ProfileCard({ person, index }: { person: typeof couple.bride; index: number }) {
  const isBride = index === 0
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay: index * 0.2 }}
      className="relative"
    >
      <div className="glass-card rounded-3xl p-6 md:p-8 text-center relative overflow-hidden group">
        {/* Floral accent top */}
        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-32 h-8">
          <svg viewBox="0 0 120 30" fill="none" className="w-full h-full">
            <path d="M0 25 Q30 5 60 15 Q90 25 120 5" stroke="#5f9ea0" strokeWidth="1" opacity="0.4" />
            <circle cx="60" cy="15" r="3" fill="#b8860b" opacity="0.3" />
          </svg>
        </div>

        {/* Image Container */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="relative w-48 h-48 md:w-56 md:h-56 mx-auto mb-6 rounded-full overflow-hidden border-4 border-primary/20 shadow-xl"
        >
          <Image
            src={person.image}
            alt={person.name}
            fill
            className={`object-cover transition-transform duration-500 group-hover:scale-110 ${
              isBride ? 'object-[center_15%]' : 'object-[center_20%]'
            }`}
          />
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        </motion.div>

        {/* Role Badge */}
        <motion.span
          initial={{ opacity: 0, scale: 0 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 + index * 0.2 }}
          className="inline-block px-4 py-1 bg-primary/10 text-primary text-xs uppercase tracking-wider rounded-full mb-3"
        >
          {person.role}
        </motion.span>

        {/* Name */}
        <h3 className="font-cursive text-3xl md:text-4xl text-foreground mb-3">
          {person.name}
        </h3>

        {/* Description */}
        <p className="text-foreground/70 text-sm md:text-base leading-relaxed max-w-xs mx-auto">
          {person.description}
        </p>

        {/* Floral accent bottom */}
        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-32 h-8 rotate-180">
          <svg viewBox="0 0 120 30" fill="none" className="w-full h-full">
            <path d="M0 25 Q30 5 60 15 Q90 25 120 5" stroke="#5f9ea0" strokeWidth="1" opacity="0.4" />
            <circle cx="60" cy="15" r="3" fill="#b8860b" opacity="0.3" />
          </svg>
        </div>
      </div>
    </motion.div>
  )
}

export function CoupleSection() {
  return (
    <section id="couple" className="relative py-16 md:py-24 px-4 overflow-hidden section-teal">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-[0.03]">
        <div className="absolute top-0 left-0 w-full h-full">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="floral-bg" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <circle cx="10" cy="10" r="1" fill="#5f9ea0" />
              </pattern>
            </defs>
            <rect width="100" height="100" fill="url(#floral-bg)" />
          </svg>
        </div>
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-cursive text-4xl md:text-5xl text-primary mb-3">
            Meet the Couple
          </h2>
          <p className="text-foreground/60 font-serif text-lg">
            Two hearts becoming one
          </p>
        </motion.div>

        {/* Couple Cards */}
        <div className="grid md:grid-cols-2 gap-8 md:gap-12">
          <ProfileCard person={couple.bride} index={0} />
          <ProfileCard person={couple.groom} index={1} />
        </div>

        {/* Heart connector for larger screens */}
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8 }}
          className="hidden md:block absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 mt-8"
        >
          <div className="w-16 h-16 flex items-center justify-center">
            <svg className="w-10 h-10 text-accent" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
            </svg>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
