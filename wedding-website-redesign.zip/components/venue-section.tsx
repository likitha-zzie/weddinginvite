'use client'

import { motion } from 'framer-motion'

export function VenueSection() {
  const venueLocation = 'https://maps.app.goo.gl/Fk3ACgEawZYdAqfp9'
  const mapEmbedUrl = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3889.4461842!2d77.9374!3d13.0011!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTPCsDAwJzA0LjAiTiA3N8KwNTYnMTQuNiJF!5e0!3m2!1sen!2sin!4v1234567890'

  return (
    <section id="venue" className="relative py-16 md:py-24 px-4 overflow-hidden bg-secondary/30">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-5">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="venue-pattern" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M10 0 L10 20 M0 10 L20 10" stroke="#c9a86c" strokeWidth="0.2" />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#venue-pattern)" />
        </svg>
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-cursive text-4xl md:text-5xl text-primary mb-3">
            Wedding Venue
          </h2>
          <p className="text-foreground/60 font-serif text-lg">
            Where our journey begins
          </p>
        </motion.div>

        {/* Venue Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass-card rounded-3xl overflow-hidden"
        >
          {/* Map */}
          <div className="relative h-64 md:h-80 w-full bg-muted">
            <iframe
              src={mapEmbedUrl}
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="absolute inset-0"
              title="Venue Location Map"
            />
            {/* Map overlay gradient */}
            <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-white/50 to-transparent pointer-events-none" />
          </div>

          {/* Venue Details */}
          <div className="p-6 md:p-10 text-center">
            {/* Venue Name */}
            <motion.h3
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="font-serif text-2xl md:text-3xl text-foreground mb-2"
            >
              R G Convention Hall
            </motion.h3>
            
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="text-foreground/70 mb-6"
            >
              Malur Town
            </motion.p>

            {/* Decorative element */}
            <motion.div
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="w-24 h-px bg-primary/40 mx-auto mb-6"
            />

            {/* Wedding Date */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="mb-6"
            >
              <p className="text-foreground/60 text-sm uppercase tracking-wider mb-1">Wedding Ceremony</p>
              <p className="font-cursive text-2xl text-primary">June 21, 2026</p>
            </motion.div>

            {/* Directions Button */}
            <motion.a
              href={venueLocation}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-3 px-8 py-4 bg-primary text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
              </svg>
              <span className="font-medium">Get Directions</span>
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
