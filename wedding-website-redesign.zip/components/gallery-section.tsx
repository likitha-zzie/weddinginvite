'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'

const galleryImages = [
  {
    src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-0YWFeba55kaICtD1aZuYhVYWFBcB9N.png',
    alt: 'Divya and Pramodh dancing',
  },
  {
    src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-oxSRt14GcRV8g42GhZVyyBaATLsrg4.png',
    alt: 'Couple on beach',
  },
  {
    src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-Aw98JLCKxige0W06krYtxyKgHsp4IA.png',
    alt: 'Couple in gazebo',
  },
  {
    src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-EqoemTLAED7HgM0PQAfKFQhOpqLhEj.png',
    alt: 'Couple on stairs',
  },
  {
    src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-tHf28gKSr2IVfNdntaaoD4PaosspRu.png',
    alt: 'Intimate moment',
  },
  {
    src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-QWqPk7sALT9M8Wx4990hh1nLvv3Rel.png',
    alt: 'Couple portrait',
  },
  {
    src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-qNJ3zW2ZgrIL9UQKLPhQH6PVWpCZ9O.png',
    alt: 'Couple holding hands',
  },
  {
    src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-SGbKamDetPbqlCJmzdS9RqXpAc86Tw.png',
    alt: 'Temple backdrop',
  },
]

export function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  return (
    <section id="gallery" className="relative py-16 md:py-24 px-4 overflow-hidden section-accent">
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-cursive text-4xl md:text-5xl text-primary mb-3">
            Captured Moments
          </h2>
          <p className="text-foreground/60 font-serif text-lg">
            Cherished memories together
          </p>
        </motion.div>

        {/* Gallery Grid - Uniform aspect ratio */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
          {galleryImages.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              whileHover={{ scale: 1.03, zIndex: 10 }}
              className="relative overflow-hidden rounded-2xl cursor-pointer group glass-card aspect-[3/4]"
              onClick={() => setSelectedImage(index)}
            >
              <Image
                src={image.src}
                alt={image.alt}
                fill
                className="object-cover object-center transition-transform duration-500 group-hover:scale-110"
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-teal-900/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              {/* Floral corner accent */}
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <svg className="w-6 h-6 text-white/70" viewBox="0 0 24 24" fill="none">
                  <path d="M12 3 C15 6 18 9 15 12 C12 15 6 12 3 9 C0 6 6 3 12 3" fill="currentColor" opacity="0.5" />
                </svg>
              </div>

              {/* View icon */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4"
            onClick={() => setSelectedImage(null)}
          >
            {/* Close button */}
            <button
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors z-10"
              onClick={() => setSelectedImage(null)}
            >
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            {/* Navigation arrows */}
            <button
              className="absolute left-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors z-10"
              onClick={(e) => {
                e.stopPropagation()
                setSelectedImage(selectedImage === 0 ? galleryImages.length - 1 : selectedImage - 1)
              }}
            >
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </button>

            <button
              className="absolute right-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors z-10"
              onClick={(e) => {
                e.stopPropagation()
                setSelectedImage(selectedImage === galleryImages.length - 1 ? 0 : selectedImage + 1)
              }}
            >
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </button>

            {/* Image */}
            <motion.div
              key={selectedImage}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative w-full max-w-4xl max-h-[85vh] aspect-[3/4] md:aspect-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <Image
                src={galleryImages[selectedImage].src}
                alt={galleryImages[selectedImage].alt}
                fill
                className="object-contain"
              />
            </motion.div>

            {/* Image counter */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/70 text-sm">
              {selectedImage + 1} / {galleryImages.length}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  )
}
