'use client'

import { motion } from 'framer-motion'
import { FloralDivider } from './floral-decorations'

export function WelcomeSection() {
  return (
    <section id="welcome" className="relative py-16 md:py-24 px-4 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c9a86c' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="max-w-3xl mx-auto relative z-10">
        <FloralDivider />
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="glass-card rounded-3xl p-8 md:p-12 text-center relative overflow-hidden"
        >
          {/* Decorative corners */}
          <div className="absolute top-4 left-4 w-12 h-12 border-t-2 border-l-2 border-primary/30 rounded-tl-lg" />
          <div className="absolute top-4 right-4 w-12 h-12 border-t-2 border-r-2 border-primary/30 rounded-tr-lg" />
          <div className="absolute bottom-4 left-4 w-12 h-12 border-b-2 border-l-2 border-primary/30 rounded-bl-lg" />
          <div className="absolute bottom-4 right-4 w-12 h-12 border-b-2 border-r-2 border-primary/30 rounded-br-lg" />

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="font-cursive text-3xl md:text-5xl text-primary mb-6"
          >
            Welcome
          </motion.h2>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="space-y-4 text-foreground/80 leading-relaxed"
          >
            <p className="font-serif text-lg md:text-xl">
              With the blessings of our parents
            </p>
            <p className="text-base md:text-lg">
              We joyfully invite you to celebrate the beginning of our forever.
              Your presence would make our special day even more memorable.
            </p>
            <p className="font-serif text-lg md:text-xl italic mt-6">
              &ldquo;Two souls, one heart, a lifetime of love&rdquo;
            </p>
          </motion.div>

          {/* Decorative element */}
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6 }}
            className="mt-8 flex justify-center"
          >
            <svg className="w-24 h-6 text-primary/40" viewBox="0 0 100 20" fill="none">
              <path d="M0 10 Q25 0 50 10 Q75 20 100 10" stroke="currentColor" strokeWidth="1" fill="none" />
              <circle cx="50" cy="10" r="3" fill="currentColor" />
            </svg>
          </motion.div>
        </motion.div>

        <FloralDivider />
      </div>
    </section>
  )
}
