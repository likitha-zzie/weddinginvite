'use client'

import { useEffect, useState, useMemo, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import confetti from 'canvas-confetti'
import Image from 'next/image'
import { FloralCorner } from './floral-decorations'

interface CountdownTime {
  days: number
  hours: number
  minutes: number
  seconds: number
}

function useCountdown(targetTimestamp: number): CountdownTime {
  const calculateTimeLeft = useCallback(() => {
    const difference = targetTimestamp - Date.now()

    if (difference > 0) {
      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      }
    }
    return { days: 0, hours: 0, minutes: 0, seconds: 0 }
  }, [targetTimestamp])

  const [timeLeft, setTimeLeft] = useState<CountdownTime>(calculateTimeLeft)

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft())
    }, 1000)

    return () => clearInterval(timer)
  }, [calculateTimeLeft])

  return timeLeft
}

function CountdownUnit({ value, label }: { value: number; label: string }) {
  return (
    <div className="flex flex-col items-center">
      <div className="countdown-box rounded-xl px-3 py-2 md:px-5 md:py-4 min-w-[60px] md:min-w-[80px]">
        <motion.span
          key={value}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="block text-2xl md:text-4xl lg:text-5xl font-serif font-bold text-amber-100"
          style={{ textShadow: '0 2px 8px rgba(184, 134, 11, 0.5)' }}
        >
          {String(value).padStart(2, '0')}
        </motion.span>
      </div>
      <span className="text-xs md:text-sm font-medium text-amber-100/90 mt-2 uppercase tracking-wider">
        {label}
      </span>
    </div>
  )
}

export function HeroSection() {
  const [isOpen, setIsOpen] = useState(false)
  const [showContent, setShowContent] = useState(false)
  const weddingTimestamp = useMemo(() => new Date('2026-06-21T00:00:00').getTime(), [])
  const timeLeft = useCountdown(weddingTimestamp)

  useEffect(() => {
    // Auto-open the invitation after a short delay
    const timer = setTimeout(() => {
      setIsOpen(true)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (isOpen) {
      // Show content after card opens
      const timer = setTimeout(() => {
        setShowContent(true)
        // Trigger confetti
        const duration = 3 * 1000
        const animationEnd = Date.now() + duration
        const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 100 }

        function randomInRange(min: number, max: number) {
          return Math.random() * (max - min) + min
        }

        const interval = setInterval(() => {
          const timeLeft = animationEnd - Date.now()

          if (timeLeft <= 0) {
            return clearInterval(interval)
          }

          const particleCount = 50 * (timeLeft / duration)
          confetti({
            ...defaults,
            particleCount,
            origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
            colors: ['#5f9ea0', '#b8860b', '#e0f0f0', '#ffffff'],
          })
          confetti({
            ...defaults,
            particleCount,
            origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
            colors: ['#5f9ea0', '#b8860b', '#e0f0f0', '#ffffff'],
          })
        }, 250)
      }, 800)

      return () => clearTimeout(timer)
    }
  }, [isOpen])

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with blur */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-0YWFeba55kaICtD1aZuYhVYWFBcB9N.png"
          alt="Divya and Pramodh"
          fill
          className="object-cover object-top blur-[2px] scale-105"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-teal-900/40 via-teal-800/30 to-teal-900/50" />
      </div>

      {/* Floral Corners */}
      <FloralCorner position="top-left" />
      <FloralCorner position="top-right" />
      <FloralCorner position="bottom-left" />
      <FloralCorner position="bottom-right" />

      {/* Opening Animation */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            className="absolute inset-0 z-50 flex items-center justify-center bg-background"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              className="text-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <motion.div
                className="relative w-64 h-80 md:w-80 md:h-96 mx-auto cursor-pointer"
                onClick={() => setIsOpen(true)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {/* Envelope/Card Animation */}
                <motion.div
                  className="absolute inset-0 glass-card rounded-2xl flex flex-col items-center justify-center p-8 border-2 border-primary/30"
                  animate={{
                    rotateY: [0, 5, -5, 0],
                    boxShadow: [
                      '0 10px 40px rgba(95, 158, 160, 0.2)',
                      '0 20px 60px rgba(95, 158, 160, 0.3)',
                      '0 10px 40px rgba(95, 158, 160, 0.2)',
                    ],
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <motion.div
                    animate={{ y: [0, -8, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    <svg className="w-16 h-16 text-primary mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </motion.div>
                  <h2 className="font-cursive text-3xl md:text-4xl text-primary mb-2">You&apos;re Invited</h2>
                  <p className="text-foreground/70 text-sm">Tap to open</p>
                </motion.div>
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <AnimatePresence>
        {showContent && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="relative z-10 text-center px-4 py-8 max-w-4xl mx-auto"
          >
            {/* Glass Card Container */}
            <div className="glass-dark rounded-3xl p-6 md:p-10 lg:p-12">
              {/* Save the Date */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-white/80 uppercase tracking-[0.3em] text-xs md:text-sm mb-4"
              >
                Save The Date
              </motion.p>

              {/* Couple Names */}
              <motion.h1
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7, duration: 0.8 }}
                className="font-cursive text-4xl md:text-6xl lg:text-7xl text-white mb-2"
                style={{ textShadow: '0 2px 10px rgba(0,0,0,0.3)' }}
              >
                Divya T N
              </motion.h1>
              <motion.div
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.9 }}
                className="text-white text-3xl md:text-4xl font-serif my-2"
              >
                &
              </motion.div>
              <motion.h1
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.1, duration: 0.8 }}
                className="font-cursive text-4xl md:text-6xl lg:text-7xl text-white mb-6"
                style={{ textShadow: '0 2px 10px rgba(0,0,0,0.3)' }}
              >
                Pramodh K N
              </motion.h1>

              {/* Wedding Date */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.3 }}
                className="mb-6"
              >
                <p className="font-serif text-xl md:text-2xl text-white/90 mb-1">June 21, 2026</p>
                <p className="text-white/70 text-sm md:text-base">R G Convention Hall, Malur Town</p>
              </motion.div>

              {/* Countdown Timer */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.5 }}
                className="flex justify-center gap-2 md:gap-4 mb-8"
              >
                <CountdownUnit value={timeLeft.days} label="Days" />
                <CountdownUnit value={timeLeft.hours} label="Hours" />
                <CountdownUnit value={timeLeft.minutes} label="Mins" />
                <CountdownUnit value={timeLeft.seconds} label="Secs" />
              </motion.div>

              {/* CTA Button */}
              <motion.a
                href="#welcome"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.7 }}
                whileHover={{ scale: 1.05, boxShadow: '0 10px 40px rgba(184, 134, 11, 0.4)' }}
                whileTap={{ scale: 0.95 }}
                className="inline-block px-8 py-3 bg-gradient-to-r from-amber-600 to-amber-700 text-white font-medium rounded-full shadow-lg hover:shadow-xl transition-all duration-300 border border-amber-500/30"
              >
                View Invitation
              </motion.a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Scroll Indicator */}
      {showContent && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-6 h-10 rounded-full border-2 border-white/50 flex items-start justify-center p-2"
          >
            <motion.div className="w-1 h-2 bg-white/70 rounded-full" />
          </motion.div>
        </motion.div>
      )}
    </section>
  )
}
