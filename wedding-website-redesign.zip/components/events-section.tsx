'use client'

import { motion } from 'framer-motion'

const events = [
  {
    name: 'Mehendi',
    date: '18 June 2026',
    time: '3:00 PM onwards',
    location: 'https://maps.app.goo.gl/QYsL5Vzje3ctrarV7',
  },
  {
    name: 'Bale Shastra',
    date: '19 June 2026',
    time: '9:00 AM to 10:00 AM',
    location: 'https://maps.app.goo.gl/QYsL5Vzje3ctrarV7',
  },
  {
    name: 'Haldi',
    date: '19 June 2026',
    time: '1:30 PM to 3:00 PM',
    location: 'https://maps.app.goo.gl/QYsL5Vzje3ctrarV7',
  },
  {
    name: 'Reception',
    date: '20 June 2026',
    time: '6:30 PM onwards',
    location: 'https://maps.app.goo.gl/QYsL5Vzje3ctrarV7',
  },
]

function EventCard({ event, index }: { event: typeof events[0]; index: number }) {
  const isLeft = index % 2 === 0

  return (
    <motion.div
      initial={{ opacity: 0, x: isLeft ? -50 : 50 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className={`flex items-center gap-4 md:gap-8 ${isLeft ? 'md:flex-row' : 'md:flex-row-reverse'}`}
    >
      {/* Card */}
      <div className="flex-1 w-full">
        <motion.div
          whileHover={{ scale: 1.02, y: -5 }}
          className="glass-card rounded-2xl p-6 md:p-8 relative overflow-hidden group"
        >
          {/* Floral border accent */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
          
          {/* Event Number */}
          <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-primary font-serif text-sm">{index + 1}</span>
          </div>

          {/* Event Name */}
          <h3 className="font-cursive text-2xl md:text-3xl text-foreground mb-4">
            {event.name}
          </h3>

          {/* Date */}
          <div className="flex items-center gap-2 text-foreground/80 mb-2">
            <svg className="w-4 h-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <span className="font-serif">{event.date}</span>
          </div>

          {/* Time */}
          <div className="flex items-center gap-2 text-foreground/80 mb-4">
            <svg className="w-4 h-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>{event.time}</span>
          </div>

          {/* Location Button */}
          <motion.a
            href={event.location}
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 hover:bg-primary/20 text-primary rounded-full text-sm transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            View Location
          </motion.a>

          {/* Bottom floral accent */}
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
        </motion.div>
      </div>

      {/* Timeline dot - visible on larger screens */}
      <div className="hidden md:flex flex-col items-center">
        <motion.div
          initial={{ scale: 0 }}
          whileInView={{ scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1 + 0.3 }}
          className="w-4 h-4 rounded-full bg-primary shadow-lg shadow-primary/30"
        />
      </div>

      {/* Spacer for alternating layout */}
      <div className="hidden md:block flex-1" />
    </motion.div>
  )
}

export function EventsSection() {
  return (
    <section id="events" className="relative py-16 md:py-24 px-4 overflow-hidden section-teal">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="dots-pattern" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
              <circle cx="5" cy="5" r="0.5" fill="#5f9ea0" />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#dots-pattern)" />
        </svg>
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-cursive text-4xl md:text-5xl text-primary mb-3">
            Wedding Events
          </h2>
          <p className="text-foreground/60 font-serif text-lg">
            Join us in celebration
          </p>
        </motion.div>

        {/* Timeline line - visible on larger screens */}
        <div className="hidden md:block absolute left-1/2 top-48 bottom-24 w-px bg-gradient-to-b from-primary/20 via-primary/40 to-primary/20" />

        {/* Events */}
        <div className="space-y-6 md:space-y-8 relative">
          {events.map((event, index) => (
            <EventCard key={event.name} event={event} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}
